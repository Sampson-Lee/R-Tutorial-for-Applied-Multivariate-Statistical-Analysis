install.packages("RODBC")
library(RODBC)

con <-odbcConnectExcel("educ_scores.xls")
tbls<-sqlTables(con)

sh1 <-sqlFetch(con, tbls$TABLE_NAME[1]); sh1

qry<-paste("select * from [", tbls$TABLE_NAME[1], "]", sep="")
sh2 <-sqlQuery(con, qry); sh2
close(con)

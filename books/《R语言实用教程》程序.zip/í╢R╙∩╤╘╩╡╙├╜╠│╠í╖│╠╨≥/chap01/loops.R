f<-c(1,1); i<-1
while (f[i] + f[i+1] < 1000) {
       f[i+2] <- f[i] + f[i+1]
       i <- i + 1;
}
f
        
n<-4; x<-array(0, dim=c(n,n))
for (i in 1:n){
    for (j in 1:n){
        x[i,j] <- 1/(i+j-1)
    }
}
x

f<-c(1,1); i<-1
repeat {
    f[i+2] <- f[i] + f[i+1]
    i <- i + 1
    if (f[i] + f[i+1] >= 1000) break
}
f

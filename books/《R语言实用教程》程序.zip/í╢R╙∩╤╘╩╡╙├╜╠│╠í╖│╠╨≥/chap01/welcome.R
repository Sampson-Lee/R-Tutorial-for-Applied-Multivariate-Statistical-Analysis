welcome <- function()
print("welcome to use R")

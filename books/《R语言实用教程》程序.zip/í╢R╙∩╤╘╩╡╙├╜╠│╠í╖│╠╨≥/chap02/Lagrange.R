Lagrange<-function(x, y, xout=x){
    n <- length(x); m <- length(xout)
    p <- matrix(0, nr=n, nc=m) 
    for (k in 1 : n){
        t <- matrix(1, nr=n, nc=m) 
        for (j in 1 : n){
            if (j != k)
                t[j,] <- (xout - x[j]) / (x[k] - x[j]);
        }
        p[k,] <- apply(t, 2, prod)
    }
    list(x=xout, y=as.vector(y%*%p))
}

A<-cbind(1, c(1, -1, 1)); A
qr.A<-qr(A); qr.A
qr.Q(qr.A)
qr.R(qr.A)
qr.X(qr.A)

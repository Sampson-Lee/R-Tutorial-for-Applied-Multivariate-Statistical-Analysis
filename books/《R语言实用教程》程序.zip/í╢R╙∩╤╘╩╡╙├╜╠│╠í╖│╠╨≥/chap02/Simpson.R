Simpson<-function(fun, a, b, tol=1e-6){
    N <- 1; h <- b-a 
    T1 <- h/2 * (fun(a) + fun(b)); S <- T1
    repeat {
        h <- h/2; x<-a+(2*1:N-1)*h
        T2 <- T1/2 + h * sum(fun(x))
        I <- (4*T2 - T1)/3
        if (abs(I-S) < tol)  break
        N <- 2 * N; T1 <- T2; S <- I
    }
    I
}

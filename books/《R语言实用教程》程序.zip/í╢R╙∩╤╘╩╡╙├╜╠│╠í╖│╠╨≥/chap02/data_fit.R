x<-c(1, -1, 2); y<-c(2, 1, 4)
X<-cbind(1,x)
solve(t(X)%*%X, t(X)%*%y)

X.qr<-qr(X)
Q<-qr.Q(X.qr); Q
R<-qr.R(X.qr); R
solve(R, t(Q)%*%y)

qr.coef(X.qr, y)
qr.solve(X, y)

z<-lsfit(x,y); z

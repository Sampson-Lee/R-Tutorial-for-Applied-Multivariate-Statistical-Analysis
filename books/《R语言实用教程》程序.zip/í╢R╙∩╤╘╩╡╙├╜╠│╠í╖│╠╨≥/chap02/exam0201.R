source("fzero.R")
f<-function(x) x^3-x-1
fzero(f, 1, 2, 1e-6)

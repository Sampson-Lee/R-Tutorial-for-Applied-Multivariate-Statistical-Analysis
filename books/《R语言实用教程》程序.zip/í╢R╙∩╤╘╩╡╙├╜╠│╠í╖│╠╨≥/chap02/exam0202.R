fun<-function(x){
    f<-x^3-x-1; g<-3*x^2-1
    list(f=f, g=g)
}
source("newton.R")
newton(fun, x=1.5, ep=1e-6)

z<-scan()
 3.23  3.90  4.75 13.41 15.94 
18.65 18.99  5.66  2.80  9.05

fun<-function(p){
    X1<-mean(z); X2<-sum(z^2)/length(z)
    f<-c(p[1]+p[2]-2*X1, p[1]^2+p[1]*p[2]+p[2]^2-3*X2)
    J<-matrix(c(1, 1, 2*p[1]+p[2], p[1]+2*p[2]),  
              2, 2, byrow=T)
    list(f=f, J=J)
}
source("Newtons.R")
Newtons(fun, c(1,2))

f<-function(x) x^3-2*x-5
optimize(f, lower=0, upper=2)

f<-function(x, a) (x-a)^2
optimize(f, interval=c(0,1), a=1/3)

x<-scan()
0.16   0.56   1.59   0.84  -1.73   0.65
2.96   1.04   2.41   0.94 192.40  -2.89

loglike <- function(p) sum(log(1+(x-p)^2))
optimize(loglike, lower=0, upper=2)

Q <- function(beta, data)
     sum(abs(data[,2] - beta[1] - beta[2] * data[,1]))
z <- optim(c(-17, 4), Q, data=cars); z

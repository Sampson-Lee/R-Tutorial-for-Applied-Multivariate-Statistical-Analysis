source("Lagrange.R")
x<-c(1,4,9); y<-c(1,2,3)
Lagrange(x, y, xout=c(5,6))

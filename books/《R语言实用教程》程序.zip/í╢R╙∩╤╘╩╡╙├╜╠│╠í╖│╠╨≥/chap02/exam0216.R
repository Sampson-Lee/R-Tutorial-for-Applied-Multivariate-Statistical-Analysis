x <- 0:10; y<-sin(x);
xout<-seq(0, 10, by=0.2)
interp1<-approxfun(x,y)
interp2<-approxfun(x,y, method="constant")
par(mai=c(.8,.8,.2,.2))
plot(x, y, pch=19, cex=1.2, xlab='X', ylab='Y')
lines(xout, sin(xout), lty=1,lwd=1, col=1, )
lines(xout, interp1(xout), lwd=2, col=4)
lines(xout, interp2(xout), lwd=2, lty=4, col=2)
legend(.5, -0.55, c("sin", "linear", "const"),  
       lty=c(1,1,4), lwd=c(1,2, 2), col=c(1, 4, 2))
legend(8.3, -0.7, "point", pch=19)  

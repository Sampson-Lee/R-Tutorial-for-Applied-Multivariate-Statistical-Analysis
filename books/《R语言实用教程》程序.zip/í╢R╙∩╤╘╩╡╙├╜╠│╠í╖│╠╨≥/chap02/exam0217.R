x<-c(1,4,9); y<-c(1,2,3); m<-c(1/2, 1/4, 1/6)
h<-splinefunH(x, y, m)
z<-h(c(3,5,6)); z

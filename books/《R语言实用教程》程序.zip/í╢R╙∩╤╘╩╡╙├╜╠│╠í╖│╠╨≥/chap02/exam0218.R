x<-0:10
y<-c(2.51, 3.30, 4.04, 4.70, 5.22, 5.54,
     5.78, 5.40, 5.57, 5.70, 5.58)
s<-spline(x,y, xout=seq(0, 10, .1))
par(mai=c(0.8, 0.8, 0.2, 0.2))
plot(x,y,pch=19, cex=1.2, col=2)
lines(s$x, s$y, lwd=2, col=4)

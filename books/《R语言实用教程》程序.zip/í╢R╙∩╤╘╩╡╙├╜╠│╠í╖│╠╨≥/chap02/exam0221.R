source("trape.R")
f <- function(x) exp(-x^2)
trape(f, -1, 1)

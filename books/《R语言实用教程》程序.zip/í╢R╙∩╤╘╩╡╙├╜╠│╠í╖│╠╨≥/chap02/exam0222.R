source("Simpson.R")
f <- function(x) exp(-x^2)
Simpson(f, -1, 1)

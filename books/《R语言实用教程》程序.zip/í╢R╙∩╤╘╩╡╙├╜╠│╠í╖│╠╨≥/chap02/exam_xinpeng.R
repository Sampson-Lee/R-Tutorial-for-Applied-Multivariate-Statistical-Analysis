# 向量的四则运算

x<-c(-1,0,2);y<-c(3,8,2)
v<-2*x+y+1;v

x<-1:5;y<-2*1:5

x %*% y
crossprod(x,y) # xT*y

x %o% y
tcrossprod(x,y) # x*yT
outer(x,y)

# 矩阵的四则运算

A<-matrix(1:6, nrow=2, byrow=T);A
B<-matrix(1:6, nrow=2);B
C<-matrix(c(1,2,2,3,3,4),nrow=2);C
D<-2*C+A/B;D

A+1
x<-1:6
A+x

A<-array(1:9, dim=c(3,3))
B<-array(9:1, dim=c(3,3))
C<-A%*%B; C

x<-1:3
A %*% x

x %*% A %*% x

# 矩阵的函数运算
A<-matrix(c(1:8, 0), nrow=3, ncol=3);A
t(A)

det(A)

v<-c(1,4,5)
diag(v)

M<-array(1:9,dim=c(3,3))
diag(M)

A<-B<-matrix(1:9,nc=3,byrow=T)
A[lower.tri(A)==T]<-0;A
B[lower.tri(B)==F]<-0;B

# 求解线性方程组
A<-matrix(c(1:8,0),nrow=3,byrow=TRUE)
b<-c(1,1,1)
x<-solve(A,b);x
B<-solve(A);B
A %*% B

A<-matrix(c(1,3,2,4),ncol=2)
norm(A)
norm(A,'I')
norm(A,'F')
norm(A,'M')
norm(A,'2')


### 1
x<-1:3; y<-4:6
z<-2*x+y+1; z 
x%*% y
x%o%y 

### 2
A<-c(1,2,4,2,5,10,0,-1,-1)
dim(A)<-c(3,3); A
B<-t(A); B
C<-A+B; C
D<-A%*%B; D
E<-A*B; E

### 3
b<-c(1, -1, 1)
det(A)
solve(A,b)
solve(A)%*%b

### 4
library(lattice); library(Matrix)
A.lu<-lu(A)
ex<-expand(A.lu); ex
A.qr<-qr(A)
Q<-qr.Q(A.qr); Q
R<-qr.R(A.qr); R
svd(A); A.svd
eigen(A)

### 5
library(lattice); library(Matrix)
H<-Hilbert(5)
chol(H)
kappa(H, exact = TRUE, norm="2")
rcond(H)

### 6
f<-function(x) 2*x^3-6*x-1
uniroot(f, interval=c(1,2))

### 7
z<-c(-4, 16, 35, -69, -102, 45, 54)
polyroot(z)

### 8
funs<-function(x){
    f<-c(-13+x[1]+5*x[2]^2-x[2]^3-2*x[2], 
         -29+x[1]+x[2]^3+x[2]^2-14*x[2])
    J<-matrix(c(1, 10*x[2]-2*x[2]^2-2, 
                1, 3*x[2]^2+2*x[2]-14), 
              nr=2, nc=2, byrow=T)
    list(f=f, J=J)
}
source("Newtons.R")
Newtons(funs, c(0.5, -2))

### 9
f<-function(x) exp(x)-3*x
optimize(f, c(0,2))

### 10
obj<-function(x){
    x1<-x[1]; x2<-x[2]; x3<-x[3]; x4<-x[4]
    F<-c(x1+10*x2, sqrt(5)*(x3-x4), 
        (x2-2*x3)^2, sqrt(10)*(x1-x4)^2)
    g <- function(x, F){
        x1<-x[1]; x2<-x[2]; x3<-x[3]; x4<-x[4]
        J<-matrix(c(1, 10, 0, 0, 
                    0, 0, sqrt(5), -sqrt(5), 
                    0, 2*(x2-2*x3), -4*(x2-2*x3), 0, 
                    2*sqrt(10)*(x1-x4), 0, 0, -2*sqrt(10)*(x1-x4)), 
           4, 4, byrow=T)
        2*t(J)%*% F      
    }
    f<- t(F) %*% F
    attr(f, "gradient")<-g(x, F)
    f
}
nlm(obj, c(3, -1, 0, 1))

### 11
fn<-function(x){
    x1<-x[1]; x2<-x[2]; x3<-x[3]; x4<-x[4]
    F<-c(x1+10*x2, sqrt(5)*(x3-x4), 
        (x2-2*x3)^2, sqrt(10)*(x1-x4)^2)
    f<- t(F) %*% F
}
gr <- function(x){
    x1<-x[1]; x2<-x[2]; x3<-x[3]; x4<-x[4]
    F<-c(x1+10*x2, sqrt(5)*(x3-x4), 
        (x2-2*x3)^2, sqrt(10)*(x1-x4)^2)
    J<-matrix(c(1, 10, 0, 0, 
                0, 0, sqrt(5), -sqrt(5), 
                0, 2*(x2-2*x3), -4*(x2-2*x3), 0, 
                2*sqrt(10)*(x1-x4), 0, 0, -2*sqrt(10)*(x1-x4)), 
       4, 4, byrow=T)
    2*t(J)%*% F      
}
optim(c(3, -1, 0, 1), fn, gr, method="BFGS")

### 12
fn<-function(x){
    x1<-x[1]; x2<-x[2]; x3<-x[3]
    f<- -x1*x2*x3+x1^2*x2+2*x1*x2^2
}
gr <- function(x){
    x1<-x[1]; x2<-x[2]; x3<-x[3]
    g<- c(-x2*x3+2*x1*x2+2*x2, 
          -x1*x3+x1^2+4*x1*x2, 
          -x1*x2)
}
nlminb(c(10,10,10), fn, gr, 
       lower=c(0,0,0), upper=c(42, 36, 72))

### 13
fn<-function(x){
    x1<-x[1]; x2<-x[2]; x3<-x[3]
    f <- 2*x1^2+2*x1*x2+2*x1*x3+2*x2^2+x3^2-8*x1-6*x2-4*x3
}
gr <- function(x){
    x1<-x[1]; x2<-x[2]; x3<-x[3]
    g <- c(4*x1+2*x2+2*x3-8, 
           2*x1+4*x2-6, 
           2*x1+2*x3-4)
}
z<-c(-1, -1, -2, 1, 0, 0, 0, 1, 0, 0, 0, 1)
A<-matrix(z, nc=3, byrow=T)
b<-c(-3, 0, 0, 0)
constrOptim(c(0.1,0.1, 0.1), fn, gr, ui=A, ci=b)

### 14
x<-c(0, 3, 5, 7, 9, 11, 12, 13, 14, 15)
y<-c(0, 1.2, 1.7, 2.0, 2.1, 2.0, 1.8, 1.2, 1.0, 1.6)
s<-spline(x,y, xout=seq(0, 15, .1))
op<-par(mai=c(0.8, 0.8, 0.2, 0.2))
plot(x,y,pch=19, cex=1.2, col=2)
lines(s$x, s$y, lwd=2, col=4)
par(op)

### 15
mt <- c(80.9, 67.2, 67.1, 50.5, 32.0, 33.6, 
        36.6, 46.8, 52.3, 62.0, 64.1, 71.2)
monthlen <- c(31, 28, 31, 30, 31, 30,
              31, 31, 30, 31, 30, 31)
month = rep(1:12, monthlen)
midmonth <- tapply(1:365, month, median)
x <- c(midmonth, midmonth[1] + 365)
y <- mt[c(1:12, 1)]
s = splinefun(x, y, method = "periodic")

op<-par(mai=c(.9, .9, .6, .2))
plot(1:365, s(1:365), type = "l", 
     lwd=2, col="blue", lab=c(7, 7, 12),
     xlab = "����",
     ylab = "����ʱ�� (Сʱ)",
     main = "ÿ�µ�ƽ������ʱ��")
points(x[-13], y[-13], pch = 19, cex=1.2, col="red")
par(op)

### 16
x <- seq(from=2, to=4, by=0.2)
y <- 1+x+x^2+x^3+x^4+x^5+x^6 
X <- cbind(1, x, x^2, x^3, x^4, x^5, x^6) 
colnames(X) <- c("beta0", "beta1", "beta2", "beta3", 
                 "beta4", "beta5", "beta6")
solve(t(X)%*%X, t(X)%*%y)
qr.solve(X,y)


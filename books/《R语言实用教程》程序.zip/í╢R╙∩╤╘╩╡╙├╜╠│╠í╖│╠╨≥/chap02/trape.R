trape<-function(fun, a, b, tol=1e-6){
    N <- 1; h <- b-a 
    T <- h/2 * (fun(a) + fun(b))
    repeat {
        h <- h/2; x<-a+(2*1:N-1)*h
        I <- T/2 + h * sum(fun(x))
        if(abs(I-T) < tol)  break
        N <- 2 * N; T = I
    }
    I
}

## ��3.2
## ����
df<-data.frame(
    Age=c(13, 13, 14, 12, 12, 15, 11, 15, 14, 14, 14, 15, 12, 
          13, 12, 16, 12, 11, 15 ), 
    Height=c(144, 166, 163, 143, 152, 169, 130, 159, 160, 175, 
             161, 170, 146, 159, 150, 183, 165, 146, 169), 
    Weight=c(38.1, 44.5, 40.8, 34.9, 38.3, 50.8, 22.9, 51.0, 
             46.5, 51.0, 46.5, 60.3, 37.7, 38.1, 45.1, 68.0, 
             58.1, 38.6, 50.8)
)

## ����ͼ
pairs(df)

pairs(~ Age + Height + Weight, data=df)

## ���Ӷ���ͼ������
source("panel.hist.R"); source("panel.cor.R")
pairs(df, diag.panel=panel.hist, 
      upper.panel=panel.smooth, lower.panel=panel.cor, 
      cex=1.5, pch = 21, bg="light blue",
      cex.labels = 2, font.labels=2)

## ����ͼ��
savePlot(filename="student_data", type="eps")

## Эͬͼ
coplot(Weight ~ Height | Age, data=df)

## ��Эͬͼ�����ӻع�ֱ��
source("panel.lm.R")
coplot(Weight ~ Height | Age, data=df, 
       panel=panel.lm, cex=1.5, pch = 21, 
       bg="light blue")

## ����ͼ��
savePlot(filename="student_data_co", type="eps")

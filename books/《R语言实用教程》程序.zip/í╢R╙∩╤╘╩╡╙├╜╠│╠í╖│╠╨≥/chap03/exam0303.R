A<-c(79.98, 80.04, 80.02, 80.04, 80.03, 80.03, 80.04,
     79.97, 80.05, 80.03, 80.02, 80.00, 80.02)    
B<-c(80.02, 79.94, 79.98, 79.97, 79.97, 80.03, 79.95,
     79.97)        
par(mai=c(0.6, 0.6, 0.3, 0.3))
boxplot(A, B, names=c('A', 'B'), col=c(2,3))

savePlot(filename="box_plot1", type="eps")

#############################################
boxplot(count ~ spray, data = InsectSprays, 
        col = "lightgray")
boxplot(count ~ spray, data = InsectSprays,
        notch = TRUE, col = 2:7, add = TRUE)


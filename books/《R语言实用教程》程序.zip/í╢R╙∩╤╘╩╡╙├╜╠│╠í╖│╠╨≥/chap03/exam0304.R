par(mai=c(0.9, 0.9, 0.6, 0.3))
attach(df)
qqnorm(Weight); qqline(Weight)
qqnorm(Height); qqline(Height)
detach()

savePlot(filename="Q-Q_plot2", type="eps")


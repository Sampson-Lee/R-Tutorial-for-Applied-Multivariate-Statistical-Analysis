y <- x <- seq(-7.5, 7.5, by = 0.5)
f <- function(x,y) {
    r <- sqrt(x^2+y^2) + 2^{-52}
    z <- sin(r)/r
}
z <- outer(x, y, f)
par(mai=c(0.0, 0.2, 0.0, 0.1))
persp(x, y, z, theta = 30, phi = 15, 
      expand = .7, col = "lightblue",
      xlab = "X", ylab = "Y", zlab = "Z")

savePlot(filename = "sinc", type = "eps")

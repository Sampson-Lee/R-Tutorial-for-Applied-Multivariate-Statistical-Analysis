y <- x <- seq(-3, 3, by = 0.125)
f <- function(x,y) {
    z <- 3*(1-x)^2*exp(-x^2 - (y+1)^2) -
       10*(x/5 - x^3 - y^5)*exp(-x^2-y^2) - 
      1/3*exp(-(x+1)^2 - y^2) 
}
z <- outer(x, y, f)
par(mai=c(0.8, 0.8, 0.2, 0.2))
contour(x, y, z, 
        levels = seq(-6.5, 8, by = 0.75),
        xlab = "X", ylab = "Y", col = "blue")

savePlot(filename = "peaks", type = "eps")

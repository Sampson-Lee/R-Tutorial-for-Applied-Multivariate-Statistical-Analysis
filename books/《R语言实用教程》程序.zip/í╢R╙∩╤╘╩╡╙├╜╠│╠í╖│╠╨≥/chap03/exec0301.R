data(pressure)
par(mai=c(0.9, 0.9, 0.6, 0.3))
for (i in c("p", "l", "b", "c", "o", "h", 
            "s", "S", "n")){
    plot(pressure, type = i, 
         main = paste("type = \"", i, "\"", sep = ""))
    if (i == "S") i="s2"
    fileName = paste("pressurePlot_", i, sep = "")
    savePlot(filename = fileName, type = "eps")
}


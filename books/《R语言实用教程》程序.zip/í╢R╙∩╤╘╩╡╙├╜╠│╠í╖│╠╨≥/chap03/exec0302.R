source("panel.hist.R"); source("panel.cor.R")
pairs(iris[1:4], diag.panel = panel.hist, 
      upper.panel = panel.smooth, lower.panel = panel.cor,
      pch = 21, bg = "light blue")

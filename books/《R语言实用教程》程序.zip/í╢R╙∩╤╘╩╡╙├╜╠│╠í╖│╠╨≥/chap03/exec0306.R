## exec_3.7
counts<-c(None=42, Some=14, Marked=28)
barplot(counts, col=c("red", "yellow", "green"))
barplot(counts, horiz=T, col=c("red", "yellow", "green"))


## exec_3.7
counts<-matrix(c(29, 7, 7, 13, 7, 21), ncol=2)
dimnames(counts)<-list(c("None", "Some", "Marked"), 
                    c("Placebo", "Treated"))
barplot(counts, 
        col=c("red", "yellow", "green"),
        main="��������ͼ", 
        legend.text=rownames(counts))

barplot(counts, beside=T,
        col=c("red", "yellow", "green"),
        main="��������ͼ", 
        legend.text=rownames(counts))
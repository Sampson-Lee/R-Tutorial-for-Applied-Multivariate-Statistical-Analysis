##exec_3.08
hist(mtcars$mpg)
hist(mtcars$mpg, breaks=12)
hist(mtcars$mpg, breaks=12, 
     col="lightblue", border="red", 
     freq = FALSE)
lines(density(mtcars$mpg), col = "blue", lwd=2)
x<-seq(10, 40, len=50)
lines(x, dnorm(x, mean(mtcars$mpg), sd(mtcars$mpg)), 
              col="red", lwd=2)

##exec_3.09
boxplot(mtcars$mpg)
boxplot(mpg~cyl, data=mtcars)

##exec_3.10
dotchart(mtcars$mpg, labels=row.names(mtcars),
         cex=0.7)

dotchart(mtcars$mpg, labels=row.names(mtcars), 
         cex=0.7,
         groups=factor(mtcars$cyl))

##exec_3.11
qqnorm(mtcars$mpg)
qqline(mtcars$mpg)

x <- 10 * (1:nrow(volcano))
y <- 10 * (1:ncol(volcano))
persp(x, y, z=volcano, 
      expand=0.7, col="lightblue", 
      theta = 30, phi = 30)
contour(x, y, z=volcano, col="blue", 
        levels=seq(100, 190, by=8))

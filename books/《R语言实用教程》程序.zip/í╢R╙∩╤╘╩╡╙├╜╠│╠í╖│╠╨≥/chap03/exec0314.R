        data(iris)
        op <- par(mai = c(1, 1, 0.3, 0.3), cex = 1.1)
        x <- iris$Sepal.Length; y <- iris$Sepal.Width
        plot(x, y, type="n", 
             xlab="Sepal Length", ylab="Sepal Width", 
             cex.lab=1.3)
        Species <- c("setosa", "versicolor", "virginica")
        pch <- c(24, 22, 25)
        for (i in 1:3){
            index <- iris$Species==Species[i]
            points(x[index], y[index], pch = pch[i], 
            col = i+1, bg = i+1) 
        }
        par(op)
        text(c(5, 5.2, 7.5),c(4, 2.2, 4), labels = Species, 
             font = 2, col = c(2, 3, 4), cex = 1.5)
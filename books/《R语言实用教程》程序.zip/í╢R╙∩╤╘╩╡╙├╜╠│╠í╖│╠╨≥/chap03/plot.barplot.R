par(mai=c(0.9, 0.9, 0.3, 0.3))

## figure 1
r<-barplot(pie.sales, space=1, col=rainbow(8))
lines(r, pie.sales, type='h', col=1, lwd=2)

## figure 2
mp <- barplot(VADeaths) 
tot <- colMeans(VADeaths)
text(mp, tot + 3, format(tot), xpd = TRUE, col = "blue")

## figure 3
barplot(VADeaths, space = 0.5, 
        col = c("lightblue", "mistyrose", "lightcyan", 
                "lavender", "cornsilk"))

## figure 4
barplot(VADeaths, beside = TRUE,
        col = c("lightblue", "mistyrose", "lightcyan", 
                "lavender", "cornsilk"), 
        legend = rownames(VADeaths), ylim = c(0, 100))

savePlot(filename = "parplot_L", type = "eps")

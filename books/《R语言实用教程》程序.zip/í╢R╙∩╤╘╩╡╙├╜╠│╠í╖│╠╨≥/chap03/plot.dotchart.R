dotchart(VADeaths, 
         main = "Death Rates in Virginia - 1940")
dotchart(t(VADeaths), 
         main = "Death Rates in Virginia - 1940")

me1 <- apply(VADeaths, 1, mean)
me2 <- apply(VADeaths, 2, mean)
dotchart(VADeaths, gdata=me2, gpch=19, 
         main = "Death Rates in Virginia - 1940")
dotchart(t(VADeaths), gdata=me1, gpch=19, 
         main = "Death Rates in Virginia - 1940")

dr  <- c(VADeaths)
nam <-dimnames(VADeaths)
age <- gl(5, 1, 20, labels = nam[[1]], ordered = T)
pos <- gl(4, 5, labels = nam[[2]], ordered = T)
dotchart(dr, labels=age, groups = pos,  
         main = "Death Rates in Virginia - 1940")
dotchart(dr, labels=pos, groups = age,
         main = "Death Rates in Virginia - 1940")

dotchart(dr, labels = age, groups = pos, 
         gdata = tapply(dr, pos, mean), gpch=19, 
         main = "Death Rates in Virginia - 1940")
dotchart(dr, labels=pos, groups = age,
         gdata = tapply(dr, age, mean), gpch=19, 
         main = "Death Rates in Virginia - 1940")

par(mai=c(0.9, 0.9, 0.6, 0.3))
attach(df)
## figure 1
hist(Height, col="lightblue", border="red",
     labels = TRUE, ylim=c(0, 7.2))
## figure 2
r<-hist(Height, breaks = 12, freq = FALSE,  
        density = 10, angle = 15+30*1:6)
text(r$mids, 0, r$counts, adj=c(.5, -.5), cex=1.2 )
lines(density(Height), col = "blue", lwd=2)
x<-seq(from=130, to=190, by=0.5)
lines(x, dnorm(x, mean(Height), sd(Height)), 
      col="red", lwd=2)
detach()

savePlot(filename = "hist_a", type = "eps")

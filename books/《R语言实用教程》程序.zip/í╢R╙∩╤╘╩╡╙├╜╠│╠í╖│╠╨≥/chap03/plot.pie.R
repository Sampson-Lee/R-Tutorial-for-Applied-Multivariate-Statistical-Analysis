pie.sales <-c(39, 200, 42, 15, 67, 276, 27, 66)
names(pie.sales) <- c("EUL", "PES", "EFA", "EDD", 
                    "ELDR", "EPP", "UNE", "other")
## figure 1
pie(pie.sales, radius = 0.9, main = "Ordinary chart") 
## figure 2
pie(pie.sales, radius = 0.9, col = rainbow(8), 
    clockwise = TRUE, main = "Rainbow colours")
## figure 3
pie(pie.sales, radius = 0.9, clockwise = TRUE, 
    col = gray(seq(0.4, 1.0, length = 8)), 
    main = "Grey colours") 
## figure 4
pie(pie.sales, radius = 0.9, 
    density = 10, angle = 15 + 15 * 1:8, 
    main = "The density of shading lines")

savePlot(filename = "pie_d", type = "eps")

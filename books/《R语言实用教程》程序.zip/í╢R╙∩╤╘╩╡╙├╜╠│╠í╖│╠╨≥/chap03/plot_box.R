op <- par(mai=c(.1, .1, 0.1, 0.1))
x <- c(0, 10, 10, 0); y <- c(0, 0, 10, 10)
xx <- c(1.5, 9, 9, 1.5); yy <- c(1.5, 1.5, 9, 9)
plot(x,y, type="n", axes=F)

box(lwd=2)
polygon(xx, yy, lwd=3)
text(5.2,9.5,"ͼ  ��", font=2, cex=1.3)
text(5.2,0.0,"��ͼ��", font=2, cex=1.2)

xx <- c(2, 8.5, 8.5, 2); yy <- c(2, 2, 8.5, 8.5)
polygon(xx, yy, lwd=2, lty=2)

arrows(4.2, 0, 4.2, 1.45, length = 0.10)
arrows(4.2, 0, 4.2, -0.35, length = 0.10)
text(3.5, 0.5,"mai[1]", cex=1.2)

arrows(1, 5.2, 1.45, 5.2, length = 0.10)
arrows(1, 5.2, -0.35,5.2, length = 0.10)
text(.6, 4.7, "mai[2]", cex=1.2)

arrows(6.5, 9.5, 6.5, 10.35, length = 0.10)
arrows(6.5, 9.5, 6.5, 9.05, length = 0.10)
text(7.2, 9.7,"mar[3]", cex=1.2)

arrows(9.5, 6, 10.35, 6, length = 0.10)
arrows(9.5, 6, 9.05,6, length = 0.10)
text(9.7, 5.5, "mar[4]", cex=1.2)

text(8.5, 0.5,"ͼ�α߿�", cex=1.2)

rx<-rnorm(50, mean=5.2, sd=1)
ry<-rnorm(50, mean=5.2, sd=1)
points(rx[rx>1.5 &&rx<9], ry[ry>1.5 &&ry<9])
par(op)
text(locator(1),"��ͼ����", cex=1.5)


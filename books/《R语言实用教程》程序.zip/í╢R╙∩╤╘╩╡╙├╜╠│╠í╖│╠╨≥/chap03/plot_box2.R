par(omi = c(.5, .5, .5, .5)); par(mfrow = c(3, 2))
## figrue 1
par(mar=c(3, 2, 2, 1))
plot(c(0,10),c(0,10), type="n", axes=F, xlab="", ylab="")
text(5,5, labels="ͼ1", cex=1.5)
box(which = "figure", lwd=2) 
box(lwd=2, lty=2) 
## figrue 2
par(mar=c(3, 3, 2, 1))
boxplot(count ~ spray, data = InsectSprays, 
        col = "lightgray")
boxplot(count ~ spray, data = InsectSprays,
        notch = TRUE, col = 2:7, add = TRUE)
box(which = "figure", lwd=2) 
## figrue 3
Height<-c(144, 166, 163, 143, 152, 169, 130, 159, 160, 175, 
          161, 170, 146, 159, 150, 183, 165, 146, 169) 
par(mar=c(4.5, 4.5, 2, 1))
hist(Height, col="lightblue", border="red",
     labels = TRUE, ylim=c(0, 7.2))
box(which = "figure", lwd=2) 
## figrue 4
plot(c(0,10),c(0,10), type="n", axes=F, xlab="", ylab="")
text(5,5, labels="ͼ4", cex=1.5)
par(mar=c(3, 2, 2, 1))
box(lwd=2, lty=2) 
box(which = "figure",lwd=2) 
## figrue 5
par(mar=c(3, 3, 2, 1))
plot(cars)
box(which = "figure",lwd=2) 
## figrue 6
par(mar=c(2, 2, 1, 1))
plot(c(0,10),c(0,10), type="n", axes=F, xlab="", ylab="")
box()
text(5,5, labels="mfg=c(3,2,3,2)", cex=1.5)
box(which = "figure", lwd=2) 

box(which = "outer", lwd=2) 
mtext("��ͼ��", line=1, outer=T, cex=1.5)



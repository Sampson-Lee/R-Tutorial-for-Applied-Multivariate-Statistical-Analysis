#### ������Ż�����
data(cars)
Q1 <- function(beta, data)
     sum(abs(data[,2] - beta[1] - beta[2] * data[,1]))
Qinf <- function(beta, data)
     max(abs(data[,2] - beta[1] - beta[2] * data[,1]))
z1 <- optim(c(-17, 4), Q1, data = cars)
zinf <- optim(c(-17, 4), Qinf, data = cars)
lm.sol<-lm(dist ~ speed, data = cars)

#### ��ͼ
op <- par(mai=c(.9, .9, .5, 0.1), cex=1.1)
plot(cars, main = "Stopping Distance versus Speed",
     ylim=c(0, 140), 
     xlab = "Speed (mph)", ylab = "Distance (ft)", 
     pch=19, col="magenta", cex.lab=1.2)
#### ����
abline(lm.sol, lwd=2, col="blue")
abline(a = z1$par[1], b = z1$par[2], lty = 4, lwd=2, 
       col="red")
abline(a = zinf$par[1], b = zinf$par[2], lty=5, 
       lwd=2, col="green")

#### ���߶κͷ���
pre<-predict(lm.sol)
x0 <- cars$speed[23]; y0 <- cars$dist[23]
segments(x0, y0, x1 = x0, y1 = pre[23], col= 1, lwd=2)
expr<-expression(paste("(", x[i],",", y[i], ")"))
text(x0+1.5, y0, expr)

#### ��ͼ��
expr1<-expression(min==sum((beta[0]+beta[1]*x[i]-y[i])^2,i==1,n))
expr2<-expression(min==sum(abs(beta[0]+beta[1]*x[i]-y[i]),i==1,n))
expr3<-expression(min==max(abs(beta[0]+beta[1]*x[i]-y[i]),i))
legend(4, 140, legend=c(expr1, expr2, expr3),
       col=c("blue", "red", "green"), lty=c(1,4, 5), lwd=2)
par(op)

savePlot(filename = "cars", type = "eps")



plot(cars, main = "", axes = F)
title(main = "Stopping Distance versus Speed")
axis(side = 1); axis(side = 2)
box(lty = 2, lwd = 2, col = 2) 

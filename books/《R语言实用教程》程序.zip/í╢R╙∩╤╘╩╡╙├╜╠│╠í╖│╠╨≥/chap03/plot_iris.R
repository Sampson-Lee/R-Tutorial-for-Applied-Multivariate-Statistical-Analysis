data(iris)
op <- par(mai=c(1, 1, 0.3, 0.3), cex=1.1)
x <- iris$Petal.Length; y <- iris$Petal.Width
plot(x, y, type="n", 
     xlab="Petal Length", ylab="Petal Width", 
     cex.lab=1.3)
Species <- c("setosa", "versicolor", "virginica")
pch <- c(24, 22, 25)
for (i in 1:3){
    index <- iris$Species==Species[i]
    points(x[index], y[index], pch=pch[i], 
    col=i+1, bg=i+1) 
}
par(op)
text(c(3, 2.5, 4),c(0.25, 1.5, 2.25), labels = Species, 
     font=2, col=c(2, 3, 4), cex=1.5)

savePlot(filename = "iris", type = "eps")


op<-par(lwd=2, omi = c(.1, .1, .1, .1))
# a
layout(matrix(1:4, 2, 2))
layout.show(4)
savePlot(file="layout_a", type="eps")

# b
layout(matrix(1:6, 3, 2, byrow=TRUE))
layout.show(6)
savePlot(file="layout_b", type="eps")

# c
layout(matrix(c(1,2,3,3), 2, 2, byrow=TRUE))
layout.show(3)
savePlot(file="layout_c", type="eps")

# d
layout(matrix(1:4, 2, 2, byrow=TRUE), widths=c(3,1), heights=c(1,3))
layout.show(4)
savePlot(file="layout_d", type="eps")

# e
layout(matrix(c(1,1,2,1), 2, 2), widths=c(2,1), heights=c(1,2))
layout.show(2)
savePlot(file="layout_e", type="eps")

# f
layout(matrix(c(0,1,2,3), 2, 2), widths=c(1,3), heights=c(1,3))
layout.show(3)
savePlot(file="layout_f", type="eps")

par(op)

par(mfrow = c(1,1))

##-- Create a scatterplot with marginal histograms -----
def.par <- par(no.readonly = TRUE, lwd=2) # save default, for resetting...
x <- pmin(3, pmax(-3, stats::rnorm(50)))
y <- pmin(3, pmax(-3, stats::rnorm(50)))
xhist <- hist(x, breaks=seq(-3,3,0.5), plot=FALSE)
yhist <- hist(y, breaks=seq(-3,3,0.5), plot=FALSE)
top <- max(c(xhist$counts, yhist$counts))
xrange <- c(-3,3)
yrange <- c(-3,3)
nf <- layout(matrix(c(2,0,1,3),2,2,byrow=TRUE), c(3,1), c(1,3), TRUE)
layout.show(nf)

par(mar=c(3,3,1,1))
plot(x, y, xlim=xrange, ylim=yrange, xlab="", ylab="")
par(mar=c(0,3,1,1))
barplot(xhist$counts, axes=FALSE, ylim=c(0, top), space=0)
par(mar=c(3,0,1,1))
barplot(yhist$counts, axes=FALSE, xlim=c(0, top), space=0, horiz=TRUE)
par(def.par)#- reset to default


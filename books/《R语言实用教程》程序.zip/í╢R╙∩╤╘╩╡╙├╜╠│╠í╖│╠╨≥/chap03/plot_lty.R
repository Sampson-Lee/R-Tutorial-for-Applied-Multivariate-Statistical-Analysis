par(mai=c(1, 0.1, 1, 0.1))
plot(c(1,1), c(6,13), type="n", axes = F, 
     xlab="", ylab="", 
     xlim=c(.5,6), ylim=c(1,13.5))
w<-c(0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0)
for (i in 1:12){
    lines(c(1,3), c(13-i,13-i), lty=i, lwd=2.5) 
    text(1-0.3, 13-i, labels=i, adj=0.5, cex=1.2)
    lines(c(4,6), c(13-i,13-i), lty=1, lwd=w[i]) 
    text(4-0.3, 13-i, labels=w[i], adj=0.5, cex=1.2)
}
text(c(2,5), c(13, 13), labels=c("lty", "lwd"), adj=0.5, cex=2)
box()

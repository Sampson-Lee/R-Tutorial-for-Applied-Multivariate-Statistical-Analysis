par(mai=c(.5, 0.1, .5, 0.1))
x<-rep(1:6, each = 6)
y<-rep(6:1, times = 6)
pch <- 0:25 
char <- c('*', '.', 'o', 'O', '0', '+', '-', '|', '%', '#')
labels <- c(pch, char)
plot(x[1:26], y[1:26], xlim=c(.7,6), ylim=c(0,7),
     axes = F, pch = pch, cex=2.5, lwd=2)
points(x[27:36], y[27:36], pch = char, cex=2.5, lwd=2)
text(x-0.3,y, labels=labels, adj=0.5, cex=1.5)
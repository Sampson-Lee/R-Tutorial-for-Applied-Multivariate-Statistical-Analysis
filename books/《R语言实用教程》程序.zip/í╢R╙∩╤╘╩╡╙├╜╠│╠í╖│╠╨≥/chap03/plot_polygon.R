op <- par(mai=c(0.9, 0.9, 0.6, 0.3))
x <- c(1, 15, 20, 30, 15)
y <- c(10, 1, 20, 15, 30)
plot(x, y, type="n", main = "Polygon")
polygon(x,y, density=5, angle=15, 
        lwd=2, border="red", lty=2, col="yellow2")
savePlot(filename = "polygon_1", type = "eps")

x <- seq(-4, 4, by=0.1)
plot(x, dnorm(x), type="l", lwd=2, col=4,
     xlim=c(-3, 3), ylim=c(-0.01, 0.4), 
     ylab = "Normal Density", 
     main = "Shadow")
abline(h=0, v=0)
z <- qnorm(1-0.05)
xx <- seq(z, 4, by=0.1)
polygon(c(xx, z), c(dnorm(xx), dnorm(4)), col="yellow1") 
text(z, -0.015, expression(Z[alpha]), adj=0.4, cex=1.1)
text(2, 0.02, expression(alpha), adj=0.5, cex=1.5)
legend(-3, 0.4, expression(alpha==0.05), adj=0.2)
par(op)

savePlot(filename = "polygon_2", type = "eps")

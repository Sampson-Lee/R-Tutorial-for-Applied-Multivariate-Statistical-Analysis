RandomWalk<-function(n=10000){
    par(mai=c(.9, .9, 0.5, 0.2))
    plot(c(0, 100), c(0, 100), type="n", 
         xlab="X", ylab="Y", 
         main="Random Walk in Two Dimensions")
    x<-y<-50
    points(50, 50, pch=16, col="red", cex=1.5)
    for (i in 1:n){
        xi<-sample(c(1, 0, -1), 1)
        yi<-sample(c(1, 0, -1), 1)
        lines(c(x, x+xi), c(y, y+yi))
        x <- x + xi; y <- y + yi
        if (x>100 | x<0 | y>100 | y<0) break
    }
}


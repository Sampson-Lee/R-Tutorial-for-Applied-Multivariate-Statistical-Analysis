birthday <- function(n){
    1-prod((365-n+1):365)/365^n
} 

bootstrap<-function(x, n, alpha=0.05){
    medians<-numeric(n)
    for(i in 1:n){
        sam<-sample(x, replace=TRUE)
        medians[i]<-mean(sam)
        # print(c(sam, medians[i]))
    }
    quantile(medians, c(alpha/2, 1-alpha/2))
}

x<-c(18.2, 9.5, 12.0, 21.1, 10.2)
x<-c(136.3, 136.6, 135.8, 135.4, 134.7, 135.0, 
     134.1, 143.3, 147.8, 148.8, 134.8, 135.2, 
     134.9, 146.5, 141.2, 135.4, 134.8, 135.8, 
     135.0, 133.7, 134.4, 134.9, 134.8, 134.5, 
     134.3, 135.2)
median(x)
bootstrap(x,n=1000)

y<-c(3.75, 40.5, 3.81, 3.23, 3.13, 3.30, 3.21, 
     3.32, 4.00, 3.90, 5.06, 3.85, 3.88, 4.06, 
     4.56, 3.60, 3.27, 4.09, 3.38, 3.37, 2.73, 
     2.95, 2.25, 2.73, 2.55, 3.06)
binom.test(sum(y>4.5), length(y))

bootstrap(y>4.5,n=1000)


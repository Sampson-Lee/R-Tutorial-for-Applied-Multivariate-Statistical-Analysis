bootstrap.ci <- function(x, B, alpha=0.05){
    medians <- numeric(B)
    for(i in 1:B){
        sam <- sample(x, replace=TRUE)
        medians[i] <- median(sam)
    }
    quantile(medians, c(alpha/2, 1-alpha/2))
}


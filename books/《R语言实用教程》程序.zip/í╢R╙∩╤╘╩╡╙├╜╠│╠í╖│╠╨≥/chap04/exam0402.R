x<-c(1,1,rep(0,13))
X<-combn(x, 3, FUN=sum)
p<-numeric(3)
for (i in 1:3)
    p[i]<-sum(X==i-1)/length(X)
p

c(22, 12, 1)/35

X<-combn(1:5, 3, FUN=max)
p<-numeric(3)
for (i in 1:3)
    p[i]<-sum(X==i+2)/length(X)
p


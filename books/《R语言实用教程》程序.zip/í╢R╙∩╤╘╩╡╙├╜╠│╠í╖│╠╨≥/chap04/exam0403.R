x <- 1:3; p <- pnorm(x) - pnorm(-x); p

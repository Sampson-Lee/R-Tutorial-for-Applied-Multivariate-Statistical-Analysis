p<-punif(160, min=150, max=200); p

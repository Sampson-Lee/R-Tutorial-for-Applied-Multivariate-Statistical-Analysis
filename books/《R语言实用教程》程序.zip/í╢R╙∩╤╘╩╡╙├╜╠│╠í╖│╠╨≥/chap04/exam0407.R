p1 <- 1-pbinom(1, size=20, prob=0.01); p1
p2 <- 1-pbinom(3, size=80, prob=0.01); p2
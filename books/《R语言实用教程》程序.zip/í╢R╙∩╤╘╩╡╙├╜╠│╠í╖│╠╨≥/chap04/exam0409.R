p1 <- 1-pbinom(1, size=1000, prob=0.001); p1
p2 <- 1-ppois(1, lambda=1000*0.001); p2

X <- c(14.6, 15.1, 14.9, 14.8, 15.2, 15.1)
n <- length(X); S <- sd(X)
t <- 0.16*sqrt(n)/S
pt(t, df = n-1) - pt(-t, df = n-1)

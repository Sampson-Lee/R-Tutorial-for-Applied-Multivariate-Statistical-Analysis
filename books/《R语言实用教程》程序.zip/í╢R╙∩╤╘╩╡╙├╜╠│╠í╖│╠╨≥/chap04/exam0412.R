source("train.R"); train(10000)

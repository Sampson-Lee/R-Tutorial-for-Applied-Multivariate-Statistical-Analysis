fun<-function(x) exp(-x^2)
source("quad1.R")
quad1(fun, a=-1, b=1)
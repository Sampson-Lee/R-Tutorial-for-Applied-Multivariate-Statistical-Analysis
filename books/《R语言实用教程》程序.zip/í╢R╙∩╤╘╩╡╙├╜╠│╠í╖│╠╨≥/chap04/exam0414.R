fun<-function(x,y) sqrt((x^2+y^2<1)*(1-x^2-y^2))
source("quad2.R")
quad2(fun, a=-1, b=1, c=-1, d=1)

x <- scan()
75.0 64.0 47.4 66.9 62.2 62.2 58.7 63.5 
66.6 64.0 57.0 69.0 56.9 50.0 72.0  

Fn <- ecdf(x)
plot(Fn, verticals= TRUE)

xx<-seq(from=min(x)-3, to=max(x)+3, by=(max(x)-min(x))/100)
yy<-pnorm(xx, mean=mean(x), sd=sd(x))
lines(xx,yy, lwd=2, col=4)

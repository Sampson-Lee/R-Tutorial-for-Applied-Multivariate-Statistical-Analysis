x<-c(rep(1,5), rep(0,15))
n<-10000
k<-0
for(i in 1:n){
   y<-sample(x, 3)
   if (sum(y)==1)
       k<-k+1
}
k/n

choose(15,2)*choose(5,1)/choose(20,3)
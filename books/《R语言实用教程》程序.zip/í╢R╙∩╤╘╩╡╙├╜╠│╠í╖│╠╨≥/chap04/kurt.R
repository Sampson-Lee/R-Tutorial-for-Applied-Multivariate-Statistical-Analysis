source("..\\chap01\\moment.R")
kurt <- function(x, flag = 1){
    mu <- mean(x)
    if (flag == 1){
        m2 <- moment(x, 2, mean=mu)
        m4 <- moment(x, 4, mean=mu)
        Ck <- m4/m2^2-3
    }
    else{
        n <- length(x); S <- sd(x)
        Ck<-n*(n+1)/((n-1)*(n-2)*(n-3))*sum((x-mu)^4)/S^4-
           (3*(n-1)^2)/((n-2)*(n-3))
    }
    Ck
}

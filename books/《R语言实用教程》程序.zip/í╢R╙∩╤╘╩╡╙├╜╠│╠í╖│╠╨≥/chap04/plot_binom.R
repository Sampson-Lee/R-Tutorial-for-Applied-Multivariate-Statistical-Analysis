op<-par(mai=c(0.9, 0.9, 0.3, 0.2))
x<-1:9
y<-dbinom(x, size=10, prob=0.3)
plot(x, y, type="h", xlim=c(0,10), lwd=2,
     xlab="x", ylab="probability")

savePlot("binom_1", type="eps")

y<-dpois(x, lambda=4)

savePlot("pois", type="eps")

par(op)

 
x <- rnorm(12)
Fn <- ecdf(x)
op <- par(mfrow=c(3,1), mgp=c(1.5, 0.8,0), mar= .1+c(3,3,2,1))
plot(Fn)
plot(Fn, verticals= TRUE)
plot(Fn, verticals= TRUE, do.points = FALSE)
par(op)
     
savePlot(file='ecdf', type='eps')

x <- rnorm(100)
par(mai=c(0.9, 0.9, 0.6, 0.2))
hist(x, prob = TRUE, col = "lightblue",
     main="Normal Distribution")
curve(dnorm(x), add = TRUE, col="red", lwd=2)
expr<-expression(paste(mu==0, ",", sigma==1))
legend(1, 0.35, legend = expr, col="red", lwd=2)

savePlot("produce_normal", type="eps")
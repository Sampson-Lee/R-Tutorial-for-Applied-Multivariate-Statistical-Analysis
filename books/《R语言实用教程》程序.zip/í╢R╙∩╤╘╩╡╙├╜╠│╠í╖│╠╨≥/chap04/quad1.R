quad1<-function(fun, a, b, M=1, n=1e6){
    x<-runif(n, min=a, max=b)
    y<-runif(n, min=0, max=M)
    k<-sum(y<fun(x))
    k/n*M*(b-a)
}


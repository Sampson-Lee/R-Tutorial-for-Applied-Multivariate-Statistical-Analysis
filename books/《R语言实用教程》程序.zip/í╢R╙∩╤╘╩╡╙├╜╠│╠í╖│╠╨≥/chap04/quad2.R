quad2<-function(fun, a, b, c, d, M=1, n=1e6){
    x<-runif(n, min=a, max=b)
    y<-runif(n, min=c, max=d)
    z<-runif(n, min=0, max=M)
    k<-sum(z<fun(x,y))
    k/n*M*(b-a)*(d-c)
}

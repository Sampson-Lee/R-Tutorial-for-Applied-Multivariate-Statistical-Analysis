source("..\\chap01\\moment.R")
skew <- function(x, flag = 1){
    mu <- mean(x)
    if (flag == 1){
        m2 <- moment(x, 2, mean=mu)
        m3 <- moment(x, 3, mean=mu)
        Cs <- m3/sqrt(m2^3)
    }
    else{
        n <- length(x); S <- sd(x)
        Cs<-n/(n-1)/(n-2)*sum((x-mu)^3)/S^3
    }
    Cs
}



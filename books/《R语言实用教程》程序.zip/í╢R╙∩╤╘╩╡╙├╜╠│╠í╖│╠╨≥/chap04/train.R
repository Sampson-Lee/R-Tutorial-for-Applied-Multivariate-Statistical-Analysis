train<-function(n){
   t1 <- sample(c(0, 5, 10), size=n, replace=T, 
                prob=c(0.7, 0.2, 0.1))
   t2 <- rnorm(n, mean=30, sd=2)
   t3 <- sample(c(28, 30, 32, 34), size=n, replace=T, 
                prob=c(0.3, 0.4, 0.2, 0.1))
   sum( t1+t2 > t3)/n
}

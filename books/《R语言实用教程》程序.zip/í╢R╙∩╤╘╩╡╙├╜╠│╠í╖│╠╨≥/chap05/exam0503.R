X<-c(78.1, 72.4, 76.2, 74.3, 77.4, 78.4, 
     76.0, 75.5, 76.7, 77.3)
Y<-c(79.1, 81.0, 77.3, 79.1, 80.0, 79.1,
     79.1, 77.3, 80.2, 82.1)
t.test(X, Y, al = "l", var.equal = T)

## ʹ�����巽�ͬģ��
t.test(X, Y, al = "l")

## ������ݼ���
t.test(X, Y, al = "l", paired = TRUE)

## ��ʽ��ʽ
obtain<-data.frame(
    value = c(78.1, 72.4, 76.2, 74.3, 77.4, 78.4, 76.0, 
              75.5, 76.7, 77.3, 79.1, 81.0, 77.3, 79.1,
              80.0, 79.1, 79.1, 77.3, 80.2, 82.1), 
    group = gl(2, 10)
)
t.test(value ~ group, data = obtain, 
       alternative = "less", var.equal = TRUE)
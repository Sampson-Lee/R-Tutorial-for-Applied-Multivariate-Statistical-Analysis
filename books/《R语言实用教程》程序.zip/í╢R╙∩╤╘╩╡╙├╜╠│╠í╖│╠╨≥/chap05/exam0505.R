prop.test(400, 10000, p=0.02)

prop.test(400, 10000, p=0.02, al="g")
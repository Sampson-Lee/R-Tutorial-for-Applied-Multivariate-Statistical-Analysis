n<-c(2000, 1500); x<-c(652, 576)
prop.test(x, n)

prop.test(x, n, al="l")


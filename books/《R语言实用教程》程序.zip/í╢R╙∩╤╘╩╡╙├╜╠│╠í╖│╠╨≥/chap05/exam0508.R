binom.test(3, 100, p=0.01)

binom.test(3, 100, p=0.01, al="g")
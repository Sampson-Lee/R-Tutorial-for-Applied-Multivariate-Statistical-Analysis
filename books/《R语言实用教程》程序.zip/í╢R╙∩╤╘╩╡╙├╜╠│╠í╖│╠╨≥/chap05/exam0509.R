poisson.test(x=12, T=1.2, r=5)

poisson.test(x=12, T=1.2, r=5, al="g")


X<-c(78.1, 72.4, 76.2, 74.3, 77.4, 78.4, 76.0, 75.5, 76.7, 77.3)
Y<-c(79.1, 81.0, 77.3, 79.1, 80.0, 79.1, 79.1, 77.3, 80.2, 82.1)
n1<-length(X); n2<-length(Y)
Sw<-((n1-1)*var(X)+(n2-1)*var(Y))/(n1+n2-2); Sw<-sqrt(Sw)
power.t.test(n=min(n1, n2), delta=mean(X)-mean(Y), sd=Sw)


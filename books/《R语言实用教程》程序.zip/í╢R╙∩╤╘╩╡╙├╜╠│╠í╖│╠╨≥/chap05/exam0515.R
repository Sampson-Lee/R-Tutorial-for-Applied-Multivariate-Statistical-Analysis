X<-c(159, 280, 101, 212, 224, 379, 179, 264,
     222, 362, 168, 250, 149, 260, 485, 170)
wilcox.test(X, alternative = "greater", mu = 225)

wilcox.test(X, alternative = "greater", mu = 225, 
            exact=F, correct=F, conf.int = T)
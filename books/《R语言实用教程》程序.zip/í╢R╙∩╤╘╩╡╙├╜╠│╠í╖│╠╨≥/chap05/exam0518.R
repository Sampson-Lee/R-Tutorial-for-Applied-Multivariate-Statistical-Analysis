x<-rep(1:4, c(62, 41, 14, 11)); y<-rep(1:4, c(20, 37, 16, 15))
wilcox.test(x, y)

cure<-data.frame(
    value = rep(1:4, c(62+20, 41+37, 14+16, 11+15)), 
    group = factor(rep(c( 1, 2, 1, 2, 1, 2, 1, 2),
                       c(62,20,41,37,14,16,11,15)))           
)
wilcox.test(value ~ group, data = cure)
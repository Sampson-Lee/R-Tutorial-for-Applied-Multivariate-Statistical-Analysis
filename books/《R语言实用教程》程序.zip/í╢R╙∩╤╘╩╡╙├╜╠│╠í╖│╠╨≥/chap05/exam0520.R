X<-c(210, 312, 170, 85, 223)
chisq.test(X)
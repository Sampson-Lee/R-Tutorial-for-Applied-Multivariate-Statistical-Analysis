x <- matrix(c(4, 5, 18, 6), nc=2)
fisher.test(x)

X <- c(49, 21, 25, 107); dim(X) <- c(2,2)
mcnemar.test(X)

mcnemar.test(X, correct=FALSE)

X<-array(c(19, 17, 141, 149), dim=c(2,2), 
         dimnames=list(defendant=c("white", "black"),
                       penalty=c("death", "non-death"))
)
X

chisq.test(X)

prop.test(X[,"death"], apply(X, 1, sum))
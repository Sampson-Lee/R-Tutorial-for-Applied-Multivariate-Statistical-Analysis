X<-array(c(19, 0, 132, 9, 11, 6, 52, 97), 
    dim=c(2,2,2), 
    dimnames=list(victim=c("white", "black"),
                  penalty=c("death", "nondeath"), 
                  defendant=c("white", "black"))
)
X
mantelhaen.test(X)

mantelhaen.test(X, exact = TRUE)
mantelhaen.test(X, exact = TRUE, alternative = "greater")

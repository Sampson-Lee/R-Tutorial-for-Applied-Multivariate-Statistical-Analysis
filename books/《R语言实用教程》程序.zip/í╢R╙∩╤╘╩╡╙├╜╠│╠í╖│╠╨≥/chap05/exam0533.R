x <- 1:6; y <- 6:1 
cor.test(x, y, method = "spearman")

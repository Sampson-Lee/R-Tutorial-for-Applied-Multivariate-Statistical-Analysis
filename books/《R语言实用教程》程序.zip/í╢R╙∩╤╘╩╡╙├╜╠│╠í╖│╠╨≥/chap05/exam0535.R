X<-scan(what = "")
+ +  -  +  - - -  +  -  + + +  - -  +  -  + +  - - -  
+  - -  +  - - - -  + + + +  - -  +  -  + +  -

runs.test(as.factor(X))

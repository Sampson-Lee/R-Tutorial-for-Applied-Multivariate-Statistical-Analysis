## �ع����
x<-c(0.10, 0.11, 0.12, 0.13, 0.14, 0.15, 0.16, 
     0.17, 0.18, 0.20, 0.21, 0.23)
y<-c(42.0, 43.5, 45.0, 45.5, 45.0, 47.5, 49.0,
     53.0, 50.0, 55.0, 55.0, 60.0)
lm.sol<-lm(y ~ 1+x)
summary(lm.sol)

## ����Ԥ��ֵ, ����ͼ
new <- data.frame(x = seq(0.10, 0.24, by=0.01))
pp<-predict(lm.sol, new, interval="prediction")
pc<-predict(lm.sol, new, interval="confidence")
par(mai=c(0.8, 0.8, 0.2, 0.2))
matplot(new$x, cbind(pp, pc[,-1]), type="l",
        xlab="X", ylab="Y", lty=c(1,5,5,2,2), 
        col=c("blue", "red", "red", "brown", "brown"), 
        lwd=2)
points(x,y, cex=1.4, pch=21, col="red", bg="orange")
legend(0.1, 63, 
       c("Points", "Fitted", "Prediction", "Confidence"), 
       pch=c(19, NA, NA, NA), lty=c(NA, 1,5,2), 
       col=c("orange", "blue", "red", "brown"))

savePlot("predict", type="eps")
## ��ȡ���ݼ�
data(anscombe)

## ���ع鲢����ع�ϵ����ֵ
ff <- y ~ x
for(i in 1:4) {
   ff[2:3] <- lapply(paste(c("y","x"), i, sep=""), as.name)
   assign(paste("lm.",i,sep=""), lmi<-lm(ff, data=anscombe))
}
GetCoef<-function(n) summary(get(n))$coef
lapply(objects(pat="lm\\.[1-4]$"), GetCoef)

## ��ͼ
op <- par(mfrow=c(2,2), mar=.1+c(4,4,1,1), oma=c(0,0,2,0))
for(i in 1:4) {
    ff[2:3] <- lapply(paste(c("y","x"), i, sep=""), as.name)
    plot(ff, data =anscombe, col="red", pch=21, 
         bg="orange", cex=1.2, xlim=c(3,19), ylim=c(3,13))
    abline(get(paste("lm.",i,sep="")), col="blue")
}
mtext("Anscombe's 4 Regression data sets", 
       outer = TRUE, cex=1.5)
par(op)

savePlot("anscombe", type="eps")

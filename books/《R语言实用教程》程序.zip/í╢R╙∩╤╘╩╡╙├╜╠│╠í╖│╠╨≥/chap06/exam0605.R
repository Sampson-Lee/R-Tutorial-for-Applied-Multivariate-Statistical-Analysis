## (1) �ع�
rt<-read.table("blood.dat", header=TRUE)
lm.sol<-lm(Y~X, data=rt); lm.sol
summary(lm.sol)

## (2) �в�ͼ
pre<-fitted.values(lm.sol)
res<-residuals(lm.sol)
rst<-rstandard(lm.sol)
par(mai=c(0.9, 0.9, 0.2, 0.1))
plot(pre, res, xlab="Fitted Values", ylab="Residuals")
savePlot("resid-1", type="eps")

plot(pre, rst, xlab="Fitted Values", 
     ylab="Standardized Residuals")
savePlot("resid-2", type="eps")

## (3) �Բв����ع�
rt$res<-res
lm.res<-lm(abs(res)~X, data=rt); lm.res
summary(lm.res)

## (4) ����в�ı�׼��
s<-lm.res$coefficients[1]+lm.res$coefficients[2]*rt$X
lm.weg<-lm(Y~X, data=rt, weights=1/s^2); lm.weg
summary(lm.weg)

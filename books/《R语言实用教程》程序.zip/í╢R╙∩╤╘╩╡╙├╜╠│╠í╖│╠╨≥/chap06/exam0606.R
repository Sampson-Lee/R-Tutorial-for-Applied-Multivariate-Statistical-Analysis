## 1. �ع����
intellect<-data.frame(
    x=c(15, 26, 10,  9, 15, 20, 18, 11,  8, 20, 7,
         9, 10, 11, 11, 10, 12, 42, 17, 11, 10),
    y=c(95, 71, 83,  91, 102,  87, 93, 100, 104, 94, 113,
        96, 83, 84, 102, 100, 105, 57, 121,  86, 100)
) 
lm.sol<-lm(y~1+x, data=intellect)
summary(lm.sol)

## 2. �ع����
influence.measures(lm.sol)
op <- par(mfrow=c(2,2), mar=0.4+c(4,4,1,1), 
          oma= c(0,0,2,0))
plot(lm.sol, 1:4)
par(op)
savePlot("diagnoses1", type="eps")

## 3. �ع�����
n<-length(intellect$x)
weights<-rep(1, n); weights[18]<-0.5
lm.correct<-lm(y~1+x, data=intellect, subset=-19,
               weights=weights)
summary(lm.correct)

## 4. ��֤
attach(intellect)
par(mai=c(0.8, 0.8, 0.2, 0.2))
plot(x, y, cex=1.2, pch=21, col="red", bg="orange")
abline(lm.sol, col="blue", lwd=2)
text(x[c(19, 18)], y[c(19, 18)], 
     label=c("19", "18"), adj=c(1.5, 0.3))
detach()
abline(lm.correct, col="red", lwd=2, lty=5)
legend(30, 120, c("Points", "Regression", "Correct Reg"), 
       pch=c(19, NA, NA), lty=c(NA, 1,5), 
       col=c("orange", "blue", "red"))
savePlot("diagnoses2", type="eps")

## 5. ����
op <- par(mfrow=c(2,2), mar=0.4+c(4,4,1,1), oma= c(0,0,2,0))
plot(lm.correct, 1:4)
par(op)
savePlot("diagnoses3", type="eps")




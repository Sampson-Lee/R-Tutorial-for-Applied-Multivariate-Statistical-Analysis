## ����
rt<-data.frame(
    x=c(20,   19.6, 19.6, 19.4, 18.4, 19,   19, 18.3,
        18.2, 18.6, 19.2, 18.2, 18.7, 18.5, 18, 17.4,
        16.5, 17.2, 17.3, 17.8, 17.3, 18.4, 16.9), 
    y=c(1.0, 1.2, 1.1, 1.4, 2.3, 1.7, 1.7, 2.4,
        2.1, 2.1, 1.2, 2.3, 1.9, 2.4, 2.6, 2.9,
        4.0, 3.3, 3.0, 3.4, 2.9, 1.9, 3.9)
)
lm.ls<-lm(y~1+x, data=rt)
summary(lm.ls)

## ��ͼ
par(mai=c(0.9, 0.9, 0.3, 0.2))
plot(rt, cex=1.2, col=2, pch=19, xlim=c(10, 20), ylim=c(1,4))
abline(lm.ls, lwd=2, col=1)

## ���15�ŵ�
points(rt$x[15], rt$y[15], cex=1.2, col=4, lwd=2)
text (rt$x[15], rt$y[15], labels="15", adj=c(-0.5, 0)) 
rt$x[15]<-10
points(rt$x[15], rt$y[15], pch=21, cex=1.2, col=4, lwd=2, bg="red")
text (rt$x[15], rt$y[15], labels="15", adj=c(-0.5, 0)) 

## �ٻ�ͼ
lm.ls<-lm(y~1+x, data=rt)
summary(lm.ls)
abline(lm.ls, lwd=2, col=4, lty=2)

savePlot("robust-1", type="eps")


## ԭʼ����
rt<-data.frame(
    x=c(20,   19.6, 19.6, 19.4, 18.4, 19,   19, 18.3,
        18.2, 18.6, 19.2, 18.2, 18.7, 18.5, 18, 17.4,
        16.5, 17.2, 17.3, 17.8, 17.3, 18.4, 16.9), 
    y=c(1.0, 1.2, 1.1, 1.4, 2.3, 1.7, 1.7, 2.4,
        2.1, 2.1, 1.2, 2.3, 1.9, 2.4, 2.6, 2.9,
        4.0, 3.3, 3.0, 3.4, 2.9, 1.9, 3.9)
)
lm.ols<-lm(y~x, data=rt); lm.ols

## ���
par(mai=c(0.9, 0.9, 0.3, 0.2))
plot(rt, cex=1.2, col=2, pch=19, xlim=c(10, 20), ylim=c(1,4))
## ���15�ŵ�
points(rt$x[15], rt$y[15], cex=1.2, col=4, lwd=2)
text (rt$x[15], rt$y[15], labels="15", adj=c(-0.5, 0)) 

## �Ķ�����
rt$x[15]<-10

## ���15�ŵ�
points(rt$x[15], rt$y[15], cex=1.2, col=4, lwd=2)
text (rt$x[15], rt$y[15], labels="15", adj=c(-0.5, 0)) 

## lqs�ع�(��ͬ����)
lqs.lts<-lqs(y~x, data=rt, method="lts"); lqs.lts
lqs.lqs<-lqs(y~x, data=rt, method="lqs"); lqs.lqs
lqs.lms<-lqs(y~x, data=rt, method="lms"); lqs.lms
lqs.S<-lqs(y~x, data=rt, method="S"); lqs.S

## ����
abline(lm.ols, lwd=2, col=1)
abline(lqs.lts, lwd=2, lty=2, col="red")
abline(lqs.lqs, lwd=2, lty=3, col="blue")
abline(lqs.lms, lwd=2, lty=4, col="brown")
abline(lqs.lms, lwd=2, lty=5, col="green")
 
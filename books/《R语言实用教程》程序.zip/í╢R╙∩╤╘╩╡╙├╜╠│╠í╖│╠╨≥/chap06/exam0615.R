x <- c(37.0, 37.5, 38.0, 38.5, 39.0, 39.5, 40.0, 40.5,
       41.0, 41.5, 42.0, 42.5, 43.0)
y <- c(3.40, 3.00, 3.00, 3.27, 2.10, 1.83, 1.53, 1.70,
       1.80, 1.90, 2.35, 2.54, 2.90)
summary(lm.sol<-lm(y~1+x+I(x^2)))

predict(lm.sol, data.frame(x=38.75), interval="p")

## ����Ԥ��ֵ, ����ͼ
new <- data.frame(x = seq(37, 43, by=0.1))
pp<-predict(lm.sol, new, interval="prediction")
pc<-predict(lm.sol, new, interval="confidence")
par(mai=c(0.8, 0.8, 0.2, 0.2))
matplot(new$x, cbind(pp, pc[,-1]), type="l",
        xlab="X", ylab="Y", lty=c(1,5,5,2,2), 
        col=c("blue", "red", "red", "brown", "brown"), 
        lwd=2)
points(x,y, cex=1.4, pch=21, col="red", bg="orange")
legend(40, 4.5, 
       c("Points", "Fitted", "Prediction", "Confidence"), 
       pch=c(19, NA, NA, NA), lty=c(NA, 1,5,2), 
       col=c("orange", "blue", "red", "brown"))

savePlot("predict-2", type="eps")



cars.lo <- loess(dist ~ speed, cars, degree = 1, 
    control = loess.control(surface = "direct"))
newdata<-data.frame(speed = seq(2, 28, 1))
cars.pr <- predict(cars.lo, newdata, se = TRUE)

par(mai=c(0.9, 0.9, 0.5, 0.1))
plot(cars, cex=1.2, pch=19, col="magenta", 
     main="Stopping Distance versus Speed", 
     xlab="Speed (mph)", ylab="Distance (ft)",
     xlim=c(2,28), ylim=c(0, 120))
lines(newdata$speed, cars.pr$fit, lty=1, col="blue", lwd=2)
lines(newdata$speed, cars.pr$fit - 2*cars.pr$se.fit, 
      lty=2, col="red", lwd=2)
lines(newdata$speed, cars.pr$fit + 2*cars.pr$se.fit, 
      lty=2, col="red", lwd=2)
savePlot("cars_loess", type="eps")
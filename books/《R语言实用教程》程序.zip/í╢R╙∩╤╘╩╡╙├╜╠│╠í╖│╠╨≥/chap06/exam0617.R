dfr<-data.frame(
    x = c(129.0, 140.0, 108.5,  88.0, 185.5, 195.0, 105.5,
          157.5, 107.5,  77.0,  81.0, 162.0, 162.0, 117.5),
    y = c(  7.5, 141.5,  28.0, 147.0,  22.5, 137.5,  85.5,
           -6.5, -81.5,   3.0,  56.5, -66.5,  84.0, -38.5),
    z = -c(1.22,  2.44,  1.83,  2.44,  1.83,  2.44,  2.44,
           2.74,  2.74,  2.44,  2.44,  2.74,  1.22,  2.74)
)
dfr.loess <- loess(z ~ x+y, dfr, degree = 2, span = 0.75)
dfr.mar <- list(x = seq(min(dfr$x), max(dfr$x), 5), 
                y = seq(min(dfr$y), max(dfr$y), 5))
dfr.lo <- predict(dfr.loess, expand.grid(dfr.mar))
par(mai = c(0.9,0.9,0.3,0.2))
contour(dfr.mar$x, dfr.mar$y, dfr.lo, 
        xlab = "X", ylab = "Y",
        levels = seq(-1.1, -2.9, -0.1), cex = 0.7)

savePlot("amcm86a", type="eps")

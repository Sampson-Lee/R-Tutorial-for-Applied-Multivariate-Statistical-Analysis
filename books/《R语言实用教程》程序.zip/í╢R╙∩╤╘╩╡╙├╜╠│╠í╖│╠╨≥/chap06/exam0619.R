x <- 0 : 5
y <- c(0, 9, 21, 47, 60, 63)
Y <- cbind(y, 70-y)
glm.sol <- glm(Y~x, family=binomial(link=logit))
summary(glm.sol)
predict(glm.sol, data.frame(x=3.5),type = "response")

d<- seq(0, 5, length=100)
names<-c("logit", "probit", "cauchit")
col <- c("black", "blue",  "brown")
lty<-c(1, 2, 4)
par(mai=c(0.9,0.9, 0.2,0.1))
plot(x, y/70, pch=19, cex=1.2, col=2, 
     xlab="X", ylab="proibability", ylim=c(0,.95))
for (i in 1:3){
    glm.sol <- glm(Y~x, family=binomial(link=names[i]))
    pre<-predict(glm.sol, data.frame(x=d), 
                 type = "response")
    lines(d, pre, lwd=2, col=col[i], lty=lty[i])
}
legend(0.2, 0.9, legend=c("points", names), 
       col=c("red", col), pch=c(19, NA, NA, NA), 
       lty=c(NA, lty), lwd=2)
savePlot("logistic", type="eps")
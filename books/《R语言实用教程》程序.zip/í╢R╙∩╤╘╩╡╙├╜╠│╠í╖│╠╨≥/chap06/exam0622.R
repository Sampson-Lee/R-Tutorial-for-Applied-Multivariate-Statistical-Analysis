noli<-data.frame(
    x = c(2, 3, 4, 5, 7, 8, 10, 11, 14, 15, 16, 18, 19),
    y = c(0.42, 2.20, 3.58, 3.50, 4.00, 3.93, 4.49, 
          4.59, 4.60, 4.90, 4.76, 5.00, 5.20)
)
lm.sol<-lm(I(1/y)~1+I(1/x), data=noli)
summary(lm.sol)

nls.sol<-nls(y~ x/(b0*x+b1), data=noli, 
             start=list(b0=0.5, b1=0.1))
summary(nls.sol)

glm.sol<-glm(y~1+I(1/x), 
             family=gaussian(link=inverse), data=noli)
summary(glm.sol)

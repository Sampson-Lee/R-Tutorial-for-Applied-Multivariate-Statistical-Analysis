## exec_6.1
rt<-read.table("exec0601.dat"); rt
lm.sol<-lm(Y~1+X, data=rt)
summary(lm.sol)

## exec_6.2
new <- data.frame(X = seq(3, 9, length=100))
pp<-predict(lm.sol, new, interval="prediction")
pc<-predict(lm.sol, new, interval="confidence")
par(mai=c(0.8, 0.8, 0.2, 0.2))
matplot(new$X, cbind(pp, pc[,-1]), type="l",
        xlab="X", ylab="Y", lty=c(1,5,5,2,2), 
        col=c("blue", "red", "red", "brown", "brown"), 
        lwd=2)
with(rt, points(X,Y, cex=1.4, pch=21, col="red", bg="orange"))
legend(3.3, 3570, 
       c("Points", "Fitted", "Prediction", "Confidence"), 
       pch=c(19, NA, NA, NA), lty=c(NA, 1,5,2), 
       col=c("orange", "blue", "red", "brown"))

## exec_6.5
influence.measures(lm.sol)
op <- par(mfrow=c(2,2), mar=0.4+c(4,4,1,1), 
          oma= c(0,0,2,0))
plot(lm.sol, 1:4)
par(op)

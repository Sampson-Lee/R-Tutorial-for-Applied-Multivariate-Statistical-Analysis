rt<-read.table("exec0603.dat"); rt
lm.sol<-lm(Y~X1+X2+X3, data=rt)
summary(lm.sol)
step(lm.sol)

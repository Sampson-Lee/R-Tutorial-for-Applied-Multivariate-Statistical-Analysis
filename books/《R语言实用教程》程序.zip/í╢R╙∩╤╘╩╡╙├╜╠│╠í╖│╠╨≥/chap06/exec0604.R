## exec_6.4
rt<-read.table("exec0604.dat"); rt
lm.sol<-lm(Y~X, data=rt)
summary(lm.sol)
pre<-predict(lm.sol)
res<-residuals(lm.sol)
rst<-rstandard(lm.sol)
plot(pre, res)
plot(pre, rst)

lm.sol<-lm(sqrt(Y)~X, data=rt)

## exec_6.6
library(MASS)
boxcox(lm.sol, lambda=seq(-.5, .5, len=50))
rt$Ylam<-with(rt, (Y^(0.2)-1)/0.2)
lm.lam<-lm(Ylam~X, data=rt)
summary(lm.lam)
pre<-predict(lm.lam)
rst<-rstandard(lm.lam)
plot(pre, rst)

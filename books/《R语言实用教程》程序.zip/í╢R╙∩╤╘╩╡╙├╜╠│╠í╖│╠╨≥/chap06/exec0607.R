## exec_6.7
rt<-read.table("body_fat.dat"); rt
lm.sol<-lm(Y~X1+X2+X3, data=rt)
summary(lm.sol)

X<-as.matrix(rt[1:3])
min(eigen(cor(X))$values)

lm.rid<-lm.ridge(Y~X1+X2+X3, data=rt, 
                 lambda=seq(0.01, .3, length=50))
plot(lm.rid)
select(lm.rid)

lm.ridge(Y~X1+X2+X3, data=rt, lambda=0.1)


rt<-read.table("exec0610.dat"); rt
lm.sol<-lm(y~x, data=rt)
summary(lm.sol)

rlm.sol<-rlm(y~x, data=rt, method="M")
summary(rlm.sol)

rlm.sol<-rlm(y~x, data=rt, method="MM")

plot(rt)
abline(lm.sol, lty=1)
abline(rlm.sol, lty=2)

abline(rlm.sol, lty=4)


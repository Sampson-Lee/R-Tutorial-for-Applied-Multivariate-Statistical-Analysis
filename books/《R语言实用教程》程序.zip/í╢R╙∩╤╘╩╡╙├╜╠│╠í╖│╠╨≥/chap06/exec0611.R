## exec_6.11
phones<-as.data.frame(phones)
plot(phones)
lm.ols<-lm(calls~year, data=phones)
lqs.lts<-lqs(calls~year, data=phones, method="lts")
lqs.lqs<-lqs(calls~year, data=phones, method="lqs")
lqs.lms<-lqs(calls~year, data=phones, method="lms")
lqs.S<-lqs(calls~year, data=phones, method="S")

abline(lm.ols)
abline(lqs.lts, lty=2)
abline(lqs.lqs, lty=3)
abline(lqs.lms, lty=4)
abline(lqs.S, lty=5)

## exec_6.13
plot(phones)
lo.1<-loess(calls~year, data=phones, span = .25, degree = 1)
newdata <- data.frame(year = seq(50, 73, 1))
lo.pr <- predict(lo.1, newdata, se = TRUE)
lines(newdata$year, lo.pr$fit)

## ��7.1
lamp<-data.frame(
    X = c(1600, 1610, 1650, 1680, 1700, 1700, 1780, 
          1500, 1640, 1400, 1700, 1750, 1640, 1550, 
          1600, 1620, 1640, 1600, 1740, 1800, 1510, 
          1520, 1530, 1570, 1640, 1600),
     A = factor(rep(1:4, c(7, 5, 8, 6)))
)
lamp.aov<-aov(X ~ A, data=lamp)
summary(lamp.aov)

lamp.lm<-lm(X ~ A, data=lamp)
anova(lamp.aov)

## ��7.6
attach(lamp)
tapply(X, A, shapiro.test)
bartlett.test(X ~ A, data=lamp)

## ��7.7
groupmeans<-tapply(X, A, mean)
groupvars<-tapply(X, A, var)
power.anova.test(groups = length(groupmeans), 
                 n=5, 
                 between.var=var(groupmeans),
                 within.var=mean(groupvars))

power.anova.test(groups = length(groupmeans), 
                 between.var=var(groupmeans),
                 within.var=mean(groupvars), 
                 power=0.9)
detach(lamp)

replications(X ~ A, data=lamp)

model.tables(lamp.aov, type="means")



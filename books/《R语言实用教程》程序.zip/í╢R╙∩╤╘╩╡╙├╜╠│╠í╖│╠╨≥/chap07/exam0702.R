## ��7.2
mouse<-data.frame(
    X = c( 2,  4, 3,  2,  4, 7, 7, 2,  2, 5, 4, 5, 6, 8, 
           5, 10, 7, 12, 12, 6, 6, 7, 11, 6, 6, 7, 9, 5, 
           5, 10, 6,  3, 10),
    A = factor(rep(1:3, c(11, 10, 12)))
)
mouse.lm<-lm(X ~ A, data=mouse)
anova(mouse.lm)

## ��7.5
attach(mouse)
tapply(X, A, mean)
pairwise.t.test(X, A)

pt<-with(mouse, pairwise.t.test(X, A, p.adjust.method = "none"))
matrix(p.adjust(pt$p.value), ncol=2)

plot(X~A)

## ����
oneway.test(X ~ A, data=mouse)
oneway.test(X ~ A, data=mouse, var.equal=TRUE)

## ��7.9
tapply(X, A, shapiro.test)
bartlett.test(X ~ A, data=mouse)

kruskal.test(X ~ A, data=mouse)
pairwise.wilcox.test(X, A)

fligner.test(X ~ A, data=mouse)
detach(mouse)

TukeyHSD(aov(X ~ A, data=mouse))
plot(TukeyHSD(aov(X ~ A, data=mouse)))


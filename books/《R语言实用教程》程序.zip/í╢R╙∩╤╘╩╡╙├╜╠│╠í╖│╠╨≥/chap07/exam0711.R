## ��7.11
pig<-data.frame(
    X = c(15, 13,  11, 12,  12,  16,  14,  17, 
          17, 16,  18, 18,  21,  22,  19,  18, 
          22, 24,  20, 23,  25,  27,  30,  32),
    Y = c(85, 83,  65, 76,  80,  91,  84,  90, 
          97, 90, 100, 95, 103, 106,  99,  94, 
          89, 91,  83, 95, 100, 102, 105, 110),
    A = gl(3, 8)
)
pig.aov1<-aov(Y ~ X+A, data=pig)
summary(pig.aov1)

pig.lm<-lm(Y ~ X+A, data=pig)
anova(pig.lm)

pig.aov2<-aov(Y ~ X*A, data=pig)
summary(pig.aov2)

anova(pig.aov1, pig.aov2)

attach(pig)
plot(X, Y, type="n")
for (i in 1:3){
   points(X[A==i], Y[A==i], pch=20+i, cex=1.2, col=1+i, bg=1+i)  
   abline(lm(Y~1+X, subset=(A==i)), lwd=2, col=1+i)
}

detach(pig)
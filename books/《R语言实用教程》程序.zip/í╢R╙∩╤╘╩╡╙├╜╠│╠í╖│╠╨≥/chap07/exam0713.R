train <- sample(1:150, 100)
z <- lda(Species ~ ., iris, prior = c(1,1,1)/3, subset = train)
(class<-predict(z, iris[-train, ])$class)
sum(class==iris$Species[-train])


##%% ��ȡ����
X<-read.table("exam0716.dat")

##%% ���ɾ���ṹ, ��ϵͳ����
d <- dist(scale(X))
method=c("complete", "average", "centroid", "ward")
for(m in method){
    hc<-hclust(d, m); class<-cutree(hc, k=5)
    print(m); print(sort(class)) 
}

for(m in method){
    hc<-hclust(d, m)
    windows()
    plclust(hc, hang=-1)
    re<-rect.hclust(hc, k=5, border="red")
    print(m); print(re) 
}


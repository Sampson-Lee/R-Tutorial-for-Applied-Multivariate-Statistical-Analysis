X<-read.table("exam0716.dat")
km<-kmeans(scale(X), 5, nstart = 20); km

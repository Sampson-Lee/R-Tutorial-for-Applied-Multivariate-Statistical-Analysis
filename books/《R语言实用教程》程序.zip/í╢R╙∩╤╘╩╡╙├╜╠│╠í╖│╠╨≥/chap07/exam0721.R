x<-scan("exam0721.dat", n=28)
names<-scan("exam0721.dat", what=" ", skip=7)

R<-matrix(1, nrow=8, ncol=8, dimnames=list(names, names))
for (i in 2:8){
    for (j in 1:(i-1)){
        R[i,j]<-x[(i-2)*(i-1)/2+j]; R[j,i]<-R[i,j]
    }
}
fa<-factanal(factors=2, covmat=R); fa


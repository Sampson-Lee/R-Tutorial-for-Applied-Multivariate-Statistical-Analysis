rt<-read.table("employ.dat")
fa<-factanal(~., factors=5, data=rt); fa

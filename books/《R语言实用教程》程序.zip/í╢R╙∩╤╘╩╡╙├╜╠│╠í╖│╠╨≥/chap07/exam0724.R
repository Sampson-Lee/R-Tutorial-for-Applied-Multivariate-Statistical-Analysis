test<-read.table("exam0724.dat")
test<-scale(test)
ca<-cancor(test[,1:3],test[,4:6]); ca


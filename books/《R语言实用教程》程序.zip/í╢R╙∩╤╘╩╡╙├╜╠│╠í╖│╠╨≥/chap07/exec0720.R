rt<-read.table('exec0720.dat')
prin.sol<-princomp(rt, cor = TRUE, scores = TRUE)
summary(prin.sol, loadings=TRUE)
pred.sol<-predict(prin.sol)
sort(pred.sol[,1])

screeplot(prin.sol)
biplot(prin.sol)
plot(pred.sol[,1], pred.sol[,2])

load<-loadings(prin.sol)
plot(load[,1:2], pch=19)
names<-c('100m', '200m', '400m', '800m','1500m', '3000m', 'Marathon')
text(load[,1], load[,2], labels =names, adj=c(0.5, -0.4))

dist<-c(100, 200, 400, 800, 1500, 3000, 42195)
for (i in 1:7){
    if (i>3){
       rt[i]<-rt[i]*60
    }
    rt[i]<-dist[i]/rt[i]
}
rt

names(rt)<-names
r<-cor(rt)
d<-as.dist(1-r); hc<-hclust(d, method="median"); 
dend<-as.dendrogram(hc)


rt<-read.table('exec0723.dat'); rt
lm.sol<-lm(Y~X1+X2+X3+X4+X5+X6, data=rt)
summary(lm.sol)

##%%���ɷַ���
pr.sol<-princomp(~X1+X2+X3+X4+X5+X6, data=rt, cor=TRUE)
summary(pr.sol)

##%% ���ɷݻع�
pre<-predict(pr.sol)
rt$z1<-pre[,1]; rt$z2<-pre[,2]
rt$z3<-pre[,3]; rt$z4<-pre[,4]

lm.sol<-lm(Y~z1+z2+z3+z4, data=rt)
summary(lm.sol)

##%% ���任, �õ�ԭ�����µĹ�ϵ����ʽ
beta<-coef(lm.sol); A<-loadings(pr.sol)[,1:4]
x.bar<-pr.sol$center; x.sd<-pr.sol$scale
coef<-A %*% beta[2:5]/x.sd
beta0 <- beta[1]- x.bar %*% coef
c(beta0, coef)


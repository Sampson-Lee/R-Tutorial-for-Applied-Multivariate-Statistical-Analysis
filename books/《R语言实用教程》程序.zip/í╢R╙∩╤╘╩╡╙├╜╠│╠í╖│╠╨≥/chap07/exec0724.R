rt<-read.table('exec0720.dat')
fa<-factanal(~., factors=2, data=rt, rotation = "none", 
scores="Bartlett"); fa

fa<-factanal(~., factors=2, data=rt, scores="Bartlett"); fa

pro<-promax(fa$loadings); pro

fa<-factanal(~., factors=2, data=rt, rotation = "promax", 
scores="Bartlett"); fa 

sort(fa$scores[,1])

plot(fa$scores, type="n")
text(fa$scores, labels = rownames(rt))

######################################################
rt<-read.table("exec0724.dat"); rt
fa<-factanal(~., factors=4, data=rt, rotation = "none", 
             scores="Bartlett"); fa

fa<-factanal(~., factors=4, data=rt, scores="Bartlett"); fa

pro<-promax(fa$loadings); pro

fa<-factanal(~., factors=4, data=rt, rotation = "promax", 
             scores="Bartlett"); fa 



rt<-read.table("exec0725.dat"); rt
test<-scale(rt)
ca<-cancor(test[,1:3], test[,4:7]); ca

U<-as.matrix(test[, 1:3])%*% ca$xcoef
V<-as.matrix(test[, 4:7])%*% ca$ycoef

plot(U[,1], V[,1])
lm.sol<-lm(V[,1]~U[,1])
abline(lm.sol)
summary(lm.sol)

write.table(rt, file = "t1.dat", sep = "& ")

library(mvtnorm)
par(mai=c(0.2, 0.2, 0, 0))
r <- 0
r <- 0.75
Sigma<-matrix(c(1, r, r, 1), nc=2)
x<-seq(from=-2.5, to= 2.5, length.out=51)
y<-seq(from=-2.5, to= 2.5, length.out=51)
z<-dmvnorm(expand.grid(x,y),
           mean = c(0,0), sigma = Sigma)
Z<-matrix(z, nr=length(x), nc=length(y))
persp(x,y,Z, theta=-30, phi=30, expand=.7)

savePlot(filename = "mvnorm_75", type = c("eps"))
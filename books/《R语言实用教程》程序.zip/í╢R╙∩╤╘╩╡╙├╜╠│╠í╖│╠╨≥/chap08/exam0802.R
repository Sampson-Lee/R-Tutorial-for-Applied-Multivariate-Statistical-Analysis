par(mai=c(0.9, 0.9, 0.2, 0.2))
r <- 0; ##r <- 0.75
Sigma<-matrix(c(1, r, r, 1), nc=2)
mu<-c(0,0); S1<-solve(Sigma)
x<-seq(from=-2.5, to= 2.5, length.out=51)
y<-seq(from=-2.5, to= 2.5, length.out=51)
n<-length(x)*length(y)
U<-as.matrix(expand.grid(x,y))
z<-numeric(n)
for (i in 1:n){
    z[i]<-(U[i,]-mu) %*% S1 %*% (U[i,]-mu)
}
Z<-matrix(z, nr=length(x), nc=length(y))
contour(x,y,Z, levels=qchisq(1-0.05, df=2), 
        xlab="X", ylab="Y")
savePlot(filename = "mvnorm-2", type = c("eps"))
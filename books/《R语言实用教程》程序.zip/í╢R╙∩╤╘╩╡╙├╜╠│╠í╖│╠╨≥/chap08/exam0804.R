library(mvtnorm)
library(survey)
library(ICS)
library(ICSNP)

rt<-read.table("exam_0804.dat") #% ������
mu0<-c(4, 50, 10)
HotellingsT2(rt, mu=mu0, test='f')
HotellingsT2(rt, mu=mu0, test='chi')


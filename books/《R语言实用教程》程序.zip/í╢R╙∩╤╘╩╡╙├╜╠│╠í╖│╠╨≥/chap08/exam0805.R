library(mvtnorm)
library(survey)
library(ICS)
library(ICSNP)

rt<-read.table("exam_0805.dat") #% ������
HotellingsT2(rt[1:2], rt[3:4], test='f')
HotellingsT2(rt[1:2], rt[3:4], test='chi')

x<-c( 6,  6, 18,  8, 11, 34, 28, 71, 43, 33, 20, 
     25, 28, 36, 35, 15, 44, 42, 54, 34, 29, 39,      
     27, 23, 64, 44, 30, 75, 26,124, 54, 30, 14,
     15, 13, 22, 29, 31, 64, 30, 64, 56, 20, 21)
X<-matrix(x, nc=2)
g<-gl(2, 11)
HotellingsT2(X~g, test='f')

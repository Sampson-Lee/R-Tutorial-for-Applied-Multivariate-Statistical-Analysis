library(mvtnorm)
library(survey)
library(ICS)
library(ICSNP)

rt<-read.table("exam_0806.dat") #% ������
X<-as.matrix(rt); G<-gl(2, 10)
HotellingsT2(X ~ G)

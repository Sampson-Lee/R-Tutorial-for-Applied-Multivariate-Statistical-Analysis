library(mvtnorm)
library(survey)
library(ICS)
library(ICSNP)

rt<-read.table("exam_0804.dat") #% ������
mu0<-c(4, 50, 10)
HP.loc.test(rt, mu = mu0, score = "rank")
HP.loc.test(rt, mu = mu0, score = "sign")
HP.loc.test(rt, mu = mu0, score = "normal")
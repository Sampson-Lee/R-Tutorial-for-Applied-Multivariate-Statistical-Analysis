library(mvtnorm)
par(mai=c(0.2, 0.2, 0, 0))
Sigma<-diag(2)

x<-seq(from=-2.5, to= 2.5, length.out=51)
y<-seq(from=-2.5, to= 2.5, length.out=51)
ex<-rep(1, length(x)); ey<-rep(1, length(y))
X<-x%o%ey; Y<-ex%o%y
z<-dmvt(cbind(as.vector(X), as.vector(Y)),
        delta = c(0,0), sigma = Sigma, 
        df = 1, log = F)
Z<-matrix(z, nr=length(x), nc=length(y))
persp(x,y,Z, theta=-30, phi=30, expand=.7)


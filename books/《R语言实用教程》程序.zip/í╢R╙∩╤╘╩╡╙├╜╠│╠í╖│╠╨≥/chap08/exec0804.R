library(mvtnorm)
library(survey)
library(ICS)
library(ICSNP)

rt<-scan("exec_0804.dat", what=list(x1=0, x2=0))
rt<-as.data.frame(rt) 
mu0<-c(190, 275)
HotellingsT2(rt, mu=mu0, test='f')
HotellingsT2(rt, mu=mu0, test='chi')

